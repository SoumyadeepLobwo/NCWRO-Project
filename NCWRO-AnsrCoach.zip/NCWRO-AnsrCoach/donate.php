<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>
		
	</title>
	<style type="text/css">
		body{}
		p.para{
			width: fit-content;
			margin-left: 195px;
			padding: 10px 90px 10px 40px;
			margin-right: 200px;
			text-align: justify;
			border: 3px solid indianred;
			border-radius: 13px;
			box-shadow: 5px 7px 12px 3px grey;

		}
		hr{
			border: 2px solid indianred;
			width: 60%;
			border-radius: 10px;
		}
		button.button{
			padding: 10px 20px;
			font-size: 20px;
			color: whitesmoke;
			background-color: indianred;
			border: none;
			border-radius: 10px;
			cursor: pointer;

		}
		button.button:hover{
			background-color: #ff616f;
		}
	</style>
</head>
<body>
	<center>
		<h2>Verify Your Entries</h2>
		<hr>
	</center>
	
<?php  

	
	$servername = '127.0.0.1';
	$username = 'root';
	$dbname = 'donationdetails';
	$password = '';	
	$tablename = 'donordetails';


	$connection = mysqli_connect($servername,$username,$password,$dbname);
	if(!$connection)
	{
		die("Could Not Connect To Server..... Please Contact NCWRO Technical Support Group");
	}
	$name = $_POST['NAME'];
	$email = $_POST['EMAIL'];
	$phone = $_POST['PHONE'];
	$amt = $_POST['DONATE'];
	$id = mt_rand(10,99999999) ;
	$sql1="INSERT INTO $tablename VALUES('$id','$name','$email','$phone','$amt')";
	$result1=mysqli_query($connection,$sql1);
	if($result1)
	{
		echo "<p class=para><font size=2>Hey <b>".$name."</b>,<br>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;We are very much grateful for your support. <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Verify the details below. If all informations are correct then click on the Donate button provided below. <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;You will receive the recipt to your payment in the email-id provided by you. <br><br> Warm Regards,<br>TEAM NCWRO<font><br><br><b>Name :            ".$name."<br>Email :           ".$email."<br>Contact Number :  ".$phone."<br>Donation Amount :  INR ".$amt." </b></p>";
	}
	

?>
<br>
	<center>
		<button class="button"><a href="https://rzp.io/l/5PmIqAdChB" style="text-decoration: none; color: white;">Click Here To Donate</a></button>
	</center>
</body>
</html>